Tesla TurOptimal V2.4 Backend

Test /health. Skal vise client:true secret:true google:true.
Endpoint: /api/route-pro-v24
